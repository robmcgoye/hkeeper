$dest = "$($ENV:ProgramData)\ntr-tech.com\"
$extracted_folder = "wpshell_hkeeper-main"
$install_folder = "hkeeper"
# $url = "https://github.com/robmcgoye/wpshell_hkeeper.git"
$url = "https://github.com/robmcgoye/wpshell_hkeeper/archive/refs/heads/main.zip"
Invoke-WebRequest -Uri $url -OutFile "main.zip"
Expand-Archive -path "main.zip" -DestinationPath $dest -Force
if (test-path($dest+$install_folder)) {
    # upgrade
    Remove-Item -Path ($dest + $install_folder) -Recurse -Exclude *.psd1 -Force
    Get-ChildItem -Path ($dest + $extracted_folder) -Recurse -Exclude *.psd1 | Move-Item -Destination ($dest + $install_folder) -Force
} else {
    # new install
    New-Item -Path $dest -Name $install_folder -ItemType "directory"
    Get-ChildItem -Path ($dest + $extracted_folder) -Recurse | Move-Item -Destination ($dest + $install_folder)
}
Remove-Item -Path ($dest + $extracted_folder)
Remove-Item -path "main.zip"

